package com.northeastern.database.project;

public class Cat {
	private long regNumber = 0;
	
	public long getRegNumber() {
		return regNumber;
	}
	public void setRegNumber(long regNumber) {
		this.regNumber = regNumber;
	}
	
}

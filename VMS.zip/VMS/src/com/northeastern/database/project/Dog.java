package com.northeastern.database.project;

public class Dog {
	private String kciNumber = "";
	private long mcNumber = 0;
	
	public String getKciNumber() {
		return kciNumber;
	}
	public void setKciNumber(String kciNumber) {
		this.kciNumber = kciNumber;
	}
	public long getMcNumber() {
		return mcNumber;
	}
	public void setMcNumber(long mcNumber) {
		this.mcNumber = mcNumber;
	}
	
}
